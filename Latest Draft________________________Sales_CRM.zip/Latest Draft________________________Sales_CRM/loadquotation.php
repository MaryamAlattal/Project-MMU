<?php
require_once("trigger_query.php");
?>
<form action="<?php echo updatequotationtooppo();?>" method="get">
    <input type="hidden" name="oppoid" value=<?php echo $_REQUEST['oppoid']; ?>>
    <div class="form-group row">
                                <div class="col-sm-12 mb-3 mb-sm-0">
                              
                               <?php 
                               $oppo_id = $_REQUEST['oppoid'];
                               $plist = show_quotations(); ?>
                                
                         
                                <label> Quotatins in the list </label>
                               
                                <select class="form-control form-control-select" name="qid">
                                        <option> Select Quotation id  </option>
                                        <?php
                                        while($row = mysqli_fetch_assoc($plist)) {
                                       ?> <option value="<?php echo $row['quotation_id']; ?>"> <?php echo $row['quotation_id']; ?> </option>
                                      <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                           
                                    </div>
                            <div class="form-group row">
                                <div class="col-sm-12 mb-3 mb-sm-0"> 
                            <button type="submit" id="btnsend" name ="btnsend" class="btn btn-primary">Save changes</button> 
                                    </div>
                                    </div>  
                                    
        
    </form>
    <?php
    if(isset($_REQUEST['btnsend'])){
    include("connection.php");
    $conn = connect();
    $oppo_id = $_REQUEST['oppoid'];
    $qid = $_REQUEST['qid'];
    $query = "UPDATE opportunity set quotation_id = ".$qid." WHERE opportunity_id= ".$oppo_id;
    echo $query;
    $flag = mysqli_query($conn,$query); 
    if($flag == 1){
    ?>
    <script>
        alert("Quotation added to opportunity record");
    </script>
    <?php
    }
    else{
    ?>
    <script>
        alert("Problem in updation of quotation");
    </script>
    <?php
    }
}
    
    ?>

   