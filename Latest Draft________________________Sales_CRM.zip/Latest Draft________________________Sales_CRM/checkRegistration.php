<?php
include ('connection.php');
$conn = connect();

$name = $_POST['FirstName'].' '.$_POST['LastName'];
$email = $_POST['Email'];
$password = $_POST['Password'];
$contact_number = $_POST['ContactNumber'];
$joining_date = $_POST['JoiningDate'];
$branch  = $_POST['Branch'];
$designation  = $_POST['Designation'];
$username  = $_POST['Username'];

$sql = "INSERT INTO staff (name,contact_no,email,joining_date,
              branch,designation,username,password) 
              values('".$name."','".$contact_number."','".$email."','".$joining_date."',
                     '".$branch."','".$designation."','".$username."','".$password."')";

if(mysqli_query($conn,$sql)){
    echo 'inserted record successfully!';
}else{
    echo 'failed, try again';
}

?>