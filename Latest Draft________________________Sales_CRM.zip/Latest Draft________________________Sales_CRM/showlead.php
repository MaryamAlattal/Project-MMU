<!DOCTYPE html>
<html lang="en">

<?php
    ERROR_REPORTING(0);
    include ("header.php");

?>

<head>
    <script>
    $(document).ready(function() {
        $("#search").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#myTable tr").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
    });
    </script>
</head>
<!-- End of Topbar -->

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <h1 class="float-start">Leads List</h1>
    <div><input type="search" id="search" placeholder="search here" class="float-end mb-4 form-control form-control-lg">
    </div>

    <div class="row">
        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Last 10 Leads </h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <form method="get">
                        <table id="myTable" class="table table-bordered" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Select </th>
                                    <th>Name</th>
                                    <th>Position</th>
                                    <th>Office</th>
                                    <th>Age</th>
                                    <th>Start date</th>
                                    <th>Salary</th>
                                    <th>Gender</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <?php
                                        require("trigger_query.php");
                                        $res = showlast10leads();

                                    ?>

                            <tbody>
                                <?php
                                          
                                          if (mysqli_num_rows($res) > 0) {
                                            // output data of each row
                                            while($row = mysqli_fetch_assoc($res)) {
                                            
                                         ?>
                                <tr>
                                    <td> <input type="checkbox" name="leadid[]" value="<?php echo $row["id"]; ?>">
                                    <td> <?php echo $row["name"]; ?> </td>
                                    <td><?php echo $row["contact_no"]; ?></td>
                                    <td><?php echo $row["email_id"]; ?></td>
                                    <td><?php echo $row["area"]; ?></td>
                                    <td><?php echo $row["city"]; ?></td>
                                    <td><?php echo $row["zipcode"]; ?></td>
                                    <td><?php if ($row["gender"]== 1) { echo "Male"; }
                                                      else if($row["gender"]== 2){ echo "Female"; }
                                                      else echo "Other";
                                            ?></td>
                                    <td><a href=""> <span class="fa fa-edit text-primary"> </span> </a>
                                        &nbsp;
                                        <a href=""> <span class="fa fa-trash text-danger"> </span> </a>
                                    </td>
                               

                         

                            <?php
                              
                                        }
                                        } else {

                                        echo "<tr> <td colspan='9'> No records in table </td></tr>";
                                        }
                                            
?>  </tr>  </tbody>
                            <tr>
                                <td colspan="9" align="right">
                                    <button class="btn btn-danger" name="delete"> Delete </button>
                                </td>
                            </tr>
                        </table>
                    </form>
                    <nav aria-label="Page navigation example">
                        <ul class="pagination">
                            <li><a class="page-link" class="page-link" href="#">1</a></li>
                            <li><a class="page-link" href="#">2</a></li>
                            <li><a class="page-link" href="#">3</a></li>
                            <li class="disabled"><a class="page-link" href="#">4</a></li>
                            <li><a class="page-link" href="#">5</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2020</span>
        </div>
    </div>
    <?php
if(isset($_REQUEST['delete'])){
//    die("going out");
   echo "working on delete multiple leads";
   $lid = $_REQUEST['leadid'];
//    print_r($lid);
    // include ("connection.php");
    $con = connect();
   for ($i = 0 ; $i < count($lid) ; $i++){
    $query = "delete from leads_tab where id = ".$lid[$i];
    $flag = mysqli_query($con,$query);
    echo $flag;
    if($flag == 1){
       echo "record # ".$lid[$i]." is deleted from table";
       header("Refresh:0; url=showlead.php");
    ?>
    <!-- <script> //window.location.reload(); 
        history.go(0);
    </script> -->
    <?php
    }
    // echo "..".$lid[$i];
   }
}
?>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="login.html">Logout</a>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="js/sb-admin-2.min.js"></script>

<!-- Page level plugins -->
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
<script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="js/demo/datatables-demo.js"></script>

</body>

</html>