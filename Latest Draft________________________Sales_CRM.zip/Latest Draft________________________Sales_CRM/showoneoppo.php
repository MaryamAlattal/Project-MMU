<?php
 include ("connection.php");
//  
 $conn = connect();

 $oid = $_REQUEST['oid'];
 echo "<br/>";
 //echo "------".$oid;
 $query = "SELECT * FROM opportunity where opportunity_id = ".$oid;
 //echo $query;
 $res = mysqli_query($conn,$query);                                                                   
?>
<form action="updateoppotodb.php">
  <input type="hidden" name="oid" value="<?php echo $oid; ?>">
<?php
  if (mysqli_num_rows($res) > 0) {
                                            // output data of each row
    while($row = mysqli_fetch_assoc($res)) {
     
        require_once ("trigger_query.php");

        $title = getquotationtitle($row['quotation_id']);
        echo "<br> Title of Quotation : <input type='text' name='title' value='".$title."'>";
        // echo $title."  ";  
        $name = getemployeebyid($row['employee_id']);
        // echo $name;
        echo "<br>Name of Employee : <input type='text' name='name' value='".$name."'>";
        ?>
        <Button name="submit" class="btn btn-lg btn-success"> Submit </Button>
        <?php
      }
    }
    if(isset($_REQUEST['submit'])){

    }
?>
</form>
