<!DOCTYPE html>
<html lang="en">

<?php
include ("header.php");
require_once ("dashboard_count.php");
?>
<!-- Content Row -->
<div class="row">
<form action="">
<div class="col-xl-10 col-lg-10 col-md-10">
    <input type="search" name="searchbox" id="searchbox" placeholder="Opportunity ID" class="float-end mb-4 form-control form-control-lg" >
</div>
<div class="col-xl-3 col-lg-3">
    <Button name="search" id="search" type="submit" class="btn btn-primary"> Search </button>
</div>
</form>
</div>
<?php
  $qdata= "";
  if(isset($_REQUEST['search'])){
    $sid = $_REQUEST['searchbox'];
    // echo "------------".$sid;
    require("trigger_query.php");
    $res = showoneoppo($sid);
    if(mysqli_num_rows($res) != 0){
        $qdata = getqdatafromoppoid($sid);
        if(mysqli_num_rows($qdata) != 0){
   ?>
                    <div class="row">

                    <div class="col-xl-12 col-lg-12">

                            <!-- Default Card Example -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Quotation #</h6>
                                </div>
                                <div class="card-body">
                                   <table>
                                        <?php
                                     
                                            // output data of each row
                                           while($row = mysqli_fetch_assoc($qdata)) {
                                            
                                         ?>
                                        <tr bgcolor = "#4e73df" style="color : #fff;"> <td style="width:600px;"> Company name : Primark LLC </td> 
                                           <td style="width:300px;"> Quotation Date : <?php echo $row['quotation_date']; ?> </td> </tr>
                                         <tr>   <td> Expiry Date : <?php echo $row['expiry_date']; ?></td><td> </td> </tr>
                                         <tr>   <td> product name : <?php echo (show_single_product($row['product_id'])); ?> </td> <td> </td></tr>
                                          <tr>  <td> Sent By :  </td> <td> </td> </tr>
                                          <tr>  <td> Bill To  :  </td>
                                        </tr>
                                        <?php
                                           }
                                        
                                      
                                        ?>
                                    </table>
                                </div>
                            </div>
                    </div>
                <?php
       }
       else{
        echo "<br> no match quotation found <br><br>";
       }    
  }
  else{
    echo "<br> no match opportunity found! <br><br>";
  }
}
  ?>
                    <div class="col-xl-6 col-lg-6">
                            <!-- Basic Card Example -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Basic Card Example</h6>
                                </div>
                                <div class="card-body">
                                    The styling for this basic card example is created by using default Bootstrap
                                    utility classes. By using utility classes, the style of the card component can be
                                    easily modified with no need for any custom CSS!
                                </div>
                            </div>
                    </div>
                        <div class="col-xl-6 col-lg-6">

                            <!-- Collapsable Card Example -->
                            <div class="card shadow mb-4">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample" class="d-block card-header py-3" data-toggle="collapse"
                                    role="button" aria-expanded="true" aria-controls="collapseCardExample">
                                    <h6 class="m-0 font-weight-bold text-primary">Collapsable Card Example</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse show" id="collapseCardExample">
                                    <div class="card-body">
                                        This is a collapsable card example using Bootstrap's built in collapse
                                        functionality. <strong>Click on the card header</strong> to see the card body
                                        collapse and expand!
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
       
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>
<script>
 function deleteo(id){
    alert(id);
    $.ajax({
        url: "showopprecord.php",
        data : {oid: id},
        success: function(result){
            // alert(result);
            if(result == 1)
               {
                 alert("record deleted successfully");
                 window.location.replace("deleteoppo.php");
               }
            else{
                alert(result);
            }
        }
    });
  }
</script>
</body>

</html>