<!DOCTYPE html>
<html lang="en">
<?php
include ("header.php");
include ("dashboard_count.php");
?>
<body class="bg-gradient-primary">

    <div class="container">

        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                     <div class="col-lg-2 d-none d-lg-block"></div>
                    <div class="col-lg-8">
                        <div class="p-10">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Add a customer</h1>
                            </div>
                            <form class="user" action='addcustomertodb.php' method="post">
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="text"  class="form-control form-control-user" name="Name" 
                                            placeholder="Name">
                                    </div>
                                    <div class="col-sm-6">
                                        <input type="text" class="form-control form-control-user" name="Address"
                                            placeholder="Address">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control form-control-user" name="Area"
                                        placeholder="Area">
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="text" class="form-control form-control-user" name="ContactNumber"
                                            placeholder="Contact number">
                                    </div>
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="text" class="form-control form-control-user" name="Postcode"
                                            placeholder="Postcode">
                                    </div>
                                </div>
                                <div class="col-sm-15">
                                        <input type="email" class="form-control form-control-user" name="Email"
                                            placeholder="Email">
                                    </div>
                                    <div class="form-group row">
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input style="margin-top:10px;" type="text" class="form-control form-control-user" name="Username"
                                            placeholder="Username">
                                    </div>
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input style="margin-top:10px;" type="password" class="form-control form-control-user" name="Password"
                                            placeholder="Password">
                                    </div>
                                 </div>
                                </div>
                                 <div class="form-group">
                                    <input type="radio" class="" name="Gender" value="1"> Male
                                    <input type="radio" class="" name="Gender" value="2"> Female
                                    <input type="radio" class="" name="Gender" value="3"> Prefer not to say

                                </div>
                                 <button type='submit' class="btn btn-primary btn-user btn-block">
                                     Register customer
                                </button>
                                <hr>
                                <!-- <a href="index.html" class="btn btn-google btn-user btn-block"> -->
                                    <!-- <i class="fab fa-google fa-fw"></i> Register with Google
                                </a> -->
                                <!-- <a href="index.html" class="btn btn-facebook btn-user btn-block">
                                    <i class="fab fa-facebook-f fa-fw"></i> Register with Facebook
                                </a> -->
                            </form>
                            <hr>
                            <div class="text-center">
                                <a class="small" href="forgot-password.html">Forgot Password?</a>
                            </div>
                            <div class="text-center">
                                <a class="small" href="index.php">Already have an account? Login!</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
   </body>
</html>

<?php
if(isset($_POST["register"])){
    require_once ("trigger_query.php");
   $flag = addcustomertodb();
  if($flag){
    ?>
    <script>alert("record inserted");</script>
    
    <?php
}
else{?>
    <script>alert("Error in insertion");</script>
 <?php
}
  return;
}

?>  