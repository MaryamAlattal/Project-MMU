<?php

function show_category(){
    // include ("connection.php");
    $conn = connect();
    // echo "-----------";
    $query = "SELECT distinct categories_name,categories_id FROM `categories`";
    $result = mysqli_query($conn,$query);
   
    return $result;
}
function show_products(){
     include ("connection.php");
    $conn = connect();
    // echo "-----------";
    $query = "SELECT distinct title,product_id FROM `product`";
    $result = mysqli_query($conn,$query);
   
    return $result;
}

function show_single_product($proid){

    $conn = connect();
    $pname = "";
    // echo "-----------";
    $query = "SELECT * FROM `product` where product_id = ".$proid;
    $result = mysqli_query($conn,$query);
    while($row = mysqli_fetch_assoc($result)){
       $pname = $row ['title'];
    }
   
    return $pname;
 }

function show_employees(){
    // include ("connection.php");
    $conn = connect();
    // echo "-----------";
    $query = "SELECT name,staff_id FROM `staff`";
    $result = mysqli_query($conn,$query);
   
    return $result;
}
// $res = show_category();
// echo mysqli_num_rows($res);
// if (mysqli_num_rows($res) > 0) {
//     // output data of each row
//     while($row = mysqli_fetch_assoc($res)) {
//       echo $row["categories_name"];
//     }
//   } else {
//     echo "0";
//   }

function showlast10leads(){
    include ("connection.php");
    $conn = connect();
    $query = "SELECT * FROM leads_tab ORDER BY updated_date  LIMIT 10;";
    $result = mysqli_query($conn,$query);
    return $result;
}

function addleadtodb(){

$conn =Connect();
$name = $_POST['FirstName'].' '.$_POST['LastName'];
$email = $_POST['Email'];
$area = $_POST['Area'];
$contact_number = $_POST['ContactNumber'];
$city = $_POST['City'];
$zipcode  = $_POST['Zipcode'];
$gender  = $_POST['Gender'];


$sql = "INSERT INTO leads_tab (name,contact_no,email_id,area,
              city,zipcode,gender) 
              values('".$name."','".$contact_number."','".$email."','".$area."',
                     '".$city."','".$zipcode."',".$gender.")";

$success = mysqli_query($conn,$sql);
if($success){
    $flag = 1;
    // header("Location:dashboard_staff.php");
}else{
    $flag= 0;
    // header("Location:addlead.php");
}
return $flag;
}

function addcustomertodb(){
    echo "add customer to db";
}
function showleadsbydate($date){
   
    $conn = connect();
    // echo "loading the records";

    $query = "SELECT * FROM `leads_tab` WHERE DATE(updated_date) ='".$date."'";
    $result = mysqli_query($conn,$query);
    return $result;
}
function addtoopportunity($lead_id,$productname, $empname ,$PrefferreDate, $str, $converse ){

    include "connection.php";
    $conn =Connect();
    // $lead_id = $_REQUEST['lid'];
    // echo "-------> ".lead_id;
    // $productname = $_REQUEST['productname'];
    // $empname = $_REQUEST['empname'];
    // $PrefferreDate = $_REQUEST['PrefferreDate'];
    // $medium = $_REQUEST['medium'];
    // $str = "";
    // if(isset($_REQUEST['medium'])){
    // foreach ($medium as $name){ 
    //     $str .= $name.",";
    // }
    // }
    // $converse = $_REQUEST['converse'];



    $sql = "INSERT INTO opportunity (lead_id, employee_id,product_name,preferred_date, pref_channel, description) 
    VALUES (".$lead_id.",".$empname.",'".$productname."','".$PrefferreDate."',
                        '".$str."','".$converse."')";

    if(mysqli_query($conn,$sql)){
        echo 'inserted record successfully!';
        $flag = 1;
        // header("Location:coverttooppo.php");
    }else{
        echo 'failed, try again';
        $flag = 0;
        // header("Location:addlead.php");
    }
return $flag;
}

function showleadsbymonth($lmonth){
// echo "calling function...".$lmonth;
  $month = explode("-",$lmonth);
  $conn = connect();
//   print_r($month);
  $query = "SELECT * FROM leads_tab WHERE MONTH(updated_date) = $month[1] AND YEAR(updated_date) = $month[0]";
  $result = mysqli_query($conn,$query);
  return $result;
}
function showallopportunities(){
   include("connection.php");
    $conn = connect();
    // echo "loading the records";
    $query = "SELECT * FROM `opportunity`" ;
    $result = mysqli_query($conn,$query);
    return $result;
}
function show_quotations(){
    include("connection.php");
    $conn = connect();
    // echo "loading the records";
    $query = "SELECT * FROM `quotation`" ;
    $result = mysqli_query($conn,$query);
    return $result;
}
function updatequotationtooppo(){
    include("connection.php");
    $conn = connect();
    $oppo_id = $_REQUEST['oppoid'];
    $qid = $_REQUEST['qid'];
    $query = "UPDATE opportunity set quotation_id = ".$qid." WHERE opportunity_id= ".$oppo_id;
    echo $query;
     $flag = mysqli_query($conn,$query); 
    if($flag == 1){
    ?>
     <script>
         alert("Quotation added to opportunity record");
    </script>
     <?php
   }
   else{
     ?>
     <script>
         alert("Problem in updation of quotation");
     </script>
    <?php
  }
}


// attempt to write Delete_quotation function:
function delete_quotations(){
    include("connection.php");
    $conn = connect();
    $qid = $_REQUEST['qid'];
    echo "loading the records";
    $query = "DELETE * FROM `quotation` WHERE quotation_id  ='".$qid."'";
    $result = mysqli_query($conn,$query);
    if($result ==1){
        echo "1";
    }
    else
    echo 0;
}

function showoneoppo($oid){
   // include("connection.php");
     $conn = connect();
     // echo "loading the records";
     $query = "SELECT * FROM `opportunity` where opportunity_id = ".$oid ;
     $result = mysqli_query($conn,$query);
     return $result;
 }

 function getqdatafromoppoid($oppoid){
    // echo "----------------";
    $conn = connect();
    $quodata = "";
    // echo "loading the records";
    $query = "SELECT quotation_id FROM `opportunity` where opportunity_id = ".$oppoid ;
    $result = mysqli_query($conn,$query);
    if (mysqli_num_rows($result) > 0) {
        // output data of each row
        $sql = "";
       while($row = mysqli_fetch_assoc($result)){
          $sql = "select * from quotation where quotation_id = ".$row['quotation_id'];
        //   echo $sql;
       }
        $quodata = mysqli_query($conn,$sql);
        // print_r($quodata);
       
    }
        else{
            echo "No match record found";
    }
    return $quodata;
 }


 function getquotationtitle($qid){
    // include("connection.php");
     $conn = connect();
     // echo "loading the records";
     $query = "SELECT title FROM `quotation` where quotation_id = ".$qid ;
    // echo $query;
    $title ="";
     $result = mysqli_query($conn,$query);
     if (mysqli_num_rows($result) > 0) {
        // output data of each row
        while($row = mysqli_fetch_assoc($result)) {
            $title = $row['title'];
        }
    }
   //  echo "-------------".$title;
     return $title;
 }

 function getquotationidfromtitle($title){
    // include("connection.php");
     $conn = connect();
     // echo "loading the records";
     $query = "SELECT quotation_id FROM `quotation` where title = '".$title."'";
     echo $query;
    $qid = 0;
     $result = mysqli_query($conn,$query);
     if (mysqli_num_rows($result) > 0) {
        // output data of each row
        while($row = mysqli_fetch_assoc($result)) {
            $qid = $row['quotation_id'];
        }
    }
   //  echo "-------------".$title;
     return $qid;
 }


 function getemployeebyid($eid){
    // include("connection.php");
     $conn = connect();
     // echo "loading the records";
     $query = "SELECT name FROM `staff` where staff_id = ".$eid ;
    // echo $query;
    $name = "";
     $result = mysqli_query($conn,$query);
     if (mysqli_num_rows($result) > 0) {
        // output data of each row
        while($row = mysqli_fetch_assoc($result)) {
            $name = $row['name'];
        }
    }
   //  echo "-------------".$title;
     return $name;
 }

 function getemployeeidbyname($ename){
    // include("connection.php");
     $conn = connect();
     // echo "loading the records";
     $query = "SELECT staff_id FROM `staff` where name = '".$ename."'" ;
    // echo $query;
     $result = mysqli_query($conn,$query);
     if (mysqli_num_rows($result) > 0) {
        // output data of each row
        while($row = mysqli_fetch_assoc($result)) {
            $sid = $row['staff_id'];
        }
    }
     echo "sid -------------".$sid."<br>";
     return $sid;
 }


///////////////////////////////
function show_customers(){
    include("connection.php");
    $conn = connect();
    // echo "loading the records";
    $query = "SELECT * FROM `customer` order by customer_id DESC LIMIT 10 " ;
    $result = mysqli_query($conn,$query);
    return $result;
}

function showlast10customers(){
    include ("connection.php");
    $conn = connect();
    $query = "SELECT * FROM customer ORDER BY updated_date DESC LIMIT 10;";
    $result = mysqli_query($conn,$query);
    return $result;
}



 






?>