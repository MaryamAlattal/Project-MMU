<!DOCTYPE html>
<html lang="en">

<?php
    include ("header.php");

?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Leads List</h1>
                    <p class="mb-4">Leads are the contacts found from online and offline sources <a target="_blank"
                            href="https://datatables.net">official DataTables documentation</a>.</p>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Last 10 Leads </h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>lead</th>
                                            <th>product</th>
                                            <th>date</th>
                                            <th>staff</th>
                                            <th colspan="2">Action</th>
                                         
                                        </tr>
                                    </thead>
                                    <?php
                                        require("trigger_query.php");
                                        $res = showallopportunities();

                                    ?>
                                    
                                    <tbody>
                                         <?php
                                          
                                          if (mysqli_num_rows($res) > 0) {
                                            // output data of each row
                                            while($row = mysqli_fetch_assoc($res)) {
                                            
                                         ?>                             
                                        <tr>

                                            <td> <?php echo $row["lead_id"]; ?> </td>
                                            <td><?php echo $row["product_name"]; ?></td>
                                            <td><?php echo $row["preferred_date"]; ?></td>
                                            <td><?php echo $row["employee_id"]; ?></td>
                                            <td><button data-toggle="modal" data-target="#oppoModal" class="btn btn-danger mymodalc" id='btn<?php echo $row["opportunity_id"]; ?>'>Update Quotation</td>
                                            <td><button data-toggle="modal" data-target="#showoppoModal" class="btn btn-success mymodalo" id='btn<?php echo $row["opportunity_id"]; ?>'>Show Opportunity</td>
                                        </tr>
                                               
                                    </tbody>
                                    <?php
                              
                                        }
                                        } else {
                                        echo "0";
                                        }

?>
                                </table>

<!---  load modal with new form (php file) -->
<script>

    $('.mymodalc').on('click',function()
    {
        var lid = $(this).attr("id");
        var str = lid.substr(3);
        alert("opportunity id : "+str);
        $('.modal-body').load('loadquotation.php?oppoid='+str,function(){
            $('#oppoModal').modal({show:true});
        });
    });

    $('.mymodalo').on('click',function()
    {
        var lid = $(this).attr("id");
        var str = lid.substr(3);
        alert("opportunity id : "+str);
        $('.modal-body').load('loadoppo.php?oppoid='+str,function(){
            $('#showoppoModal').modal({show:true});
        });
    });
    $('#btnsend').click(function(){
       
        alert("inside document.ready")
        var qid = $("#qid").val();
        var oppoid = $("#oppoid").val();
        var ajaxurl = 'loadquotationtodb.php',
        data1 =  {'qid': qid , 'oppoid' : oppoid};
        console.log(data1);
        $.ajax({
                cache: false,
                type: "GET",
                url: ajaxurl,
                data: data1,
                
                //processData: true, //<-- this isn't needed because it defaults to true anyway
                success: function (result) {
                    alert("data");
                },
                error: function (xhr, textStatus, errorThrown) { alert(textStatus + ':' + errorThrown); }
            });
        return false;
    });
</script>
                               
                                <!--- code for displaying a separate modal form -->
<div class="modal" tabindex="-1" id="oppoModal" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Add Quotation to Opportunity</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
      </div>
      <div class="modal-footer">
      
        <button type="button" class="btn btn-secondary " data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-------  first modal completed -------->
    <!--- code for displaying a separate modal form -->
    <div class="modal" tabindex="-1" id="showoppoModal" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Show Single Opportunity</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
      </div>
      <div class="modal-footer">
      
        <button type="button" class="btn btn-secondary " data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js">

</body>



</html>