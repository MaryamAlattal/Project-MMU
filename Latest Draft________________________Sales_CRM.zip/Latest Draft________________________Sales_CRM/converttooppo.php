<!DOCTYPE html>
<html lang="en">
<?php
include ("header.php");
include ("dashboard_count.php");

?>
<body class="bg-gradient-primary">

    <div class="container">
      
        <div class="card o-hidden border-0 shadow-lg my-2">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                     <!-- <div class="col-lg-1 d-none d-lg-block"></div> -->
                    <div class="col-lg-12">
                        <div class="p-10">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Convert to Opportunity form!</h1>
                            </div>
                      
                        <form class="user" action='#' method="get">
                       
                            <label> Select Either Date Or Month </label>
                            
                                <div class="form-group row">
                              
                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="date"  class="form-control form-control-user" name="ldate" 
                                            placeholder="Enter Date">
                                    </div>
                                
                                    <div class="col-sm-6">
                                        <input type="month" class="form-control form-control-user" name="lmonth"
                                            placeholder="Month">
                                    </div>
                                </div>
                                <button name="register" class="btn btn-primary btn-user btn-block">
                                    Show Leads
                                </button>
                            </form>
                        </div>
                                <?php
                                    if (isset($_REQUEST["register"])) {
                                        if($_REQUEST['ldate'] == ""){
                                            require_once("trigger_query.php");
                                            $month = $_REQUEST['lmonth'];
                                            $res = showleadsbymonth($month);
                                        }
                                        else{
                                        $date = $_REQUEST['ldate'];
                                        // echo "----".$date;
                                        // echo "calling the function";
                                        require_once ("trigger_query.php");
                                        $res = showleadsbydate($date);
                                    // print_r($res);
                                    }
                                }
                                  ?>
                    <div class="card shadow mb-2">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary"> Leads Data of 
                            <?php if (isset($date) != "") 
                                     echo $date; 
                                 else if (isset($month) != "") echo $month; ?> 
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Contact No.</th>
                                            <th>Email ID</th>
                                            <th>Area</th>
                                            <th>City</th>
                                            <th>ZipCode</th>
                                            <th>Gender</th>
                                            <th>Convert</th>
                                        </tr>
                                    </thead>
                                  
                                    
                                    <tbody>
                                         <?php
                                          
                                        //   if (mysqli_num_rows($res) > 0) {
                                            // output data of each row
                                            if(isset($res)){
                                            while($row = mysqli_fetch_assoc($res)) {
                                            
                                         ?>                             
                                        <tr>
                                                                                       
                                            <td><?php echo $row["name"]; ?>   </td>
                                            <td><?php echo $row["contact_no"]; ?></td>
                                            <td><?php echo $row["email_id"]; ?></td>
                                            <td><?php echo $row["area"]; ?></td>
                                            <td><?php echo $row["city"]; ?></td>
                                            <td><?php echo $row["zipcode"]; ?></td>

                                            <td><?php 
                                            if ($row['gender'] == 1) echo "Male";
                                            else if ($row['gender'] == 2) echo "Female";
                                            else echo "Other";
                                            ?></td>
                                           <td> <Button  id="btn<?php echo $row['id']; ?>" class="btn btn-sm btn-warning mymodalc" data-toggle="modal" data-target="#exampleModal"> Fill Form </button> 
                                           <br>
                                           <Button  id="btn<?php echo $row['id']; ?>" class="btn btn-sm btn-success mymodalq" data-toggle="modal" data-target="#quotationModal"> Fill Quotation </button>
                                        </td>
                                        </tr>
                                               
                                    </tbody>
                                    <?php
                                            }
                                         }
                                        // } else {
                                        // echo "0";
                                        // }

?>
                                </table>
<!--- code for displaying a separate modal form -->
<div class="modal" tabindex="-1" id="exampleModal" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Confirmation Form</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
      </div>
      <div class="modal-footer">
      
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!--- code for displaying a separate modal form -->
<div class="modal" tabindex="-1" id="quotationModal" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Quotation Form</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
      </div>
      <div class="modal-footer">
      
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- code for modal ends -->

                            </div>
                        </div>
                    </div>

                </div>
                        </div>
                    </div>
                </div>
         
        </div>

    </div>
   </body>

    <script>
$(document).ready(function(e){
    // alert("ready");
    $('.mymodalc').on('click',function()
    {
        var lid = $(this).attr("id");
        var str = lid.substr(3);
        alert("id : "+str);
        $('.modal-body').load('addoppmodel.php?lid='+str,function(){
            $('#exampleModal').modal({show:true});
        });
    });
    $('.mymodalq').on('click',function()
    {
        var lid = $(this).attr("id");
        var str = lid.substr(3);
       // alert("id : "+str);
        $('.modal-body').load('addquotation.php?lid='+str,function(){
            $('#quotationModal').modal({show:true});
        });
    });
})
</script>
<?php
                            if(isset($_REQUEST["flag"])){
                                // echo "------------->".$_REQUEST["flag"];
                                if($_REQUEST["flag"] == 1){
                                ?>
                                    <script>
                                            var lid = $(this).attr("id");
                                            var str = lid.substr(3);
                                        // alert("id : "+str);
                                            $('.modal-body').load('addquotation.php?lid='+str,function(){
                                                $('#quotationModal').modal({show:true});
                                            });
                                    </script>
                                <?php
                                }
                                else{
                                    ?>
                                    <script>
                                        console.log("no flag detected");
                                            // alert("<?php echo "no flag "; ?>");
                                    </script>
                                <?php
                                }
                            }
                            else{
                                echo "No setup of flag";
                            }
                            ?>
</html>
