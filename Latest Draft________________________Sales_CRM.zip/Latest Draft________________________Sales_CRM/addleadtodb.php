<?php
include "connection.php";
$conn =Connect();
$name = $_POST['FirstName'].' '.$_POST['LastName'];
$email = $_POST['Email'];
$area = $_POST['Area'];
$contact_number = $_POST['ContactNumber'];
$city = $_POST['City'];
$zipcode  = $_POST['Zipcode'];
$gender  = $_POST['Gender'];


$sql = "INSERT INTO leads_tab (name,contact_no,email_id,area,
              city,zipcode,gender) 
              values('".$name."','".$contact_number."','".$email."','".$area."',
                     '".$city."','".$zipcode."',".$gender.")";

if(mysqli_query($conn,$sql)){
    //echo 'inserted record successfully!';
    header("Location:dashboard_staff.php");
}else{
    //echo 'failed, try again';
    header("Location:addlead.php");
}

?>