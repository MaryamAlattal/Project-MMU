<?php
include "connection.php";
$conn =Connect();
$lead_id = $_REQUEST['lid'];
$productname = $_REQUEST['productname'];
$empname = $_REQUEST['empname'];
$PrefferreDate = $_REQUEST['PrefferreDate'];
$medium = $_REQUEST['medium'];
$str = "";
if(isset($_REQUEST['medium'])){
foreach ($medium as $name){ 
     $str .= $name.",";
}
}
$converse = $_REQUEST['converse'];



$sql = "INSERT INTO opportunity (lead_id, employee_id,product_name,preferred_date, pref_channel, description) 
VALUES (".$lead_id.",".$empname.",'".$productname."','".$PrefferreDate."',
                     '".$str."','".$converse."')";

if(mysqli_query($conn,$sql)){
    echo 'inserted record successfully!';
    header("Location:converttooppo.php?flag=1");
}else{
    echo 'failed, try again';
     header("Location:addlead.php?flag=0");
}




?>