<?php
include "connection.php";
$conn =Connect();
$name = $_POST['Name'];
$address = $_POST['Address'];
$area = $_POST['Area'];
$contact_number = $_POST['ContactNumber'];
$postcode = $_POST['Postcode'];
$email  = $_POST['Email'];
$username = $_POST['Username'];
$password  = $_POST['Password'];
$gender  = $_POST['Gender'];


$sql = "INSERT INTO customer (name,address,area,phone,postcode,email,
              username,password,gender) 
              values('".$name."','".$address."','".$area."','".$contact_number."','".$postcode."',
              '".$email."','".$username."','".$password."',".$gender.")";

if(mysqli_query($conn,$sql)){
    //echo 'inserted record successfully!';
    header("Location:dashboard_staff.php");
}else{
    //echo 'failed, try again';
    header("Location:addcustomer.php");
}

?>