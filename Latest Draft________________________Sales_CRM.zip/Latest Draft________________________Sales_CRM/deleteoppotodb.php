<?php
include "connection.php";

// function delete_opportunity(){
//     include("connection.php");
    $conn = connect();
    $qid = $_REQUEST['oid'];
    echo "loading the records with id : ".$oid;
    $query = "DELETE FROM `opportunity` WHERE opportunity_id  =".$oid;
      echo $query;
    $result = mysqli_query($conn,$query) or die("Query Problem!");
    return $result;
//}
?>