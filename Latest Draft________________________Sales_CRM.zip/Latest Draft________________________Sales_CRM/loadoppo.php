<?php
   require("trigger_query.php");
   $opid  = $_REQUEST['oppoid'];
   $res = showoneoppo($opid);
   echo "<table border='1' class='table table-hovered table-success'>";
   while($row = mysqli_fetch_assoc($res)) {
        echo "<tr><td>".$row["product_name"]."</td></tr>";
        echo "<tr><td>".$row["quotation_id"]."</td></tr>";
        echo "<tr><td>".$row["preferred_date"]."</td></tr>";
        echo "<tr><td>".$row["pref_channel"]."</td></tr>";
   }
   echo "</table>";
?>