<?php
require_once("trigger_query.php");
?>
<form action="addtooppo.php" method="get">
    <input type="text" name="lid" value=<?php echo $_REQUEST['lid']; ?>
    <div class="form-group row">
                                <div class="col-sm-12 mb-3 mb-sm-0">
                                <div class="col-sm-12 ">
                               <?php $plist = show_products(); ?>
                                <select class="form-control form-control-select" name="productname">
                                        <option> Select Product </option>
                                        <?php
                                        while($row = mysqli_fetch_assoc($plist)) {
                                       ?> <option> <?php echo $row['title']; ?> </option>
                                      <?php
                                        }
                                        ?>
                                    </select>
                                    </div>
                                <div class="col-sm-12 mb-3 my-2 mb-sm-0">
                                <label> Employee who has attended the customer </label>
                                <?php $elist = show_employees(); ?>
                                <select class="form-control form-control-select" name="empname">
                                        <option> Select Employee  </option>
                                        <?php
                                        while($row = mysqli_fetch_assoc($elist)) {
                                       ?> <option value="<?php echo $row['staff_id']; ?>"> <?php echo $row['name']; ?> </option>
                                      <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                           
                            <div class="form-group">
                                <label> Preferred date to contact </label>
                                <input type="date" class="form-control form-control-user" name="PrefferreDate">
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-12 mb-3 mb-sm-0">
                                <label> Preferred date to contact </label>
                               <input type="checkbox" value="Email" name="medium[]">  Email 
                               <input type="checkbox" value="Phone" name="medium[]">  Phone 
                               <input type="checkbox" value="WhatsApp" name="medium[]"> WhatsApp  

                                </div>
                                <div class="col-sm-12">
                                <label> Insight of the Conversation</label>
                                <Textarea cols="100" rows="3" class="form-control" name="converse">
                                    </Textarea>
                                   
                                </div>
                            </div>  
                            <div class="form-group row">
                                <div class="col-sm-12 mb-3 mb-sm-0"> 
                            <button type="submit" name ="btnsend" class="btn btn-primary">Save changes</button> 
                                    </div>
                                    </div>  
                                    
        
    </form>

    <?php
    //  include ("trigger_query.php");
    if (isset($_GET['btnsend'])){
        ?>
        <script> alert("in send button"); </script>
        <?php
        $lead_id = $_REQUEST['lid'];
        $productname = $_REQUEST['productname'];
        $empname = $_REQUEST['empname'];
        $PrefferreDate = $_REQUEST['PrefferreDate'];
        $medium = $_REQUEST['medium'];
        $str = "";
        if(isset($_REQUEST['medium'])){
        foreach ($medium as $name){ 
            $str .= $name.",";
        }
        }
        $converse = $_REQUEST['converse'];
      $flag =  addtoopportunity($lead_id,$productname, $empname ,$PrefferreDate, $str, $converse);
      echo "------------------";
      if($flag == 1){
        ?>
        <script>
            alert("Lead converted to Opportunity");
        </script>
        <?php
      }
      else{
        ?>
        <script>
            alert("Problem in Conversion to Opportunity");
        </script>
        <?php
      }
      }
    
    ?>