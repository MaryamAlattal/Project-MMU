<?php
  include("connection.php");
  $conn = connect();
  $qid = $_REQUEST['qid'];
  echo "loading the records";
  $query = "DELETE FROM `quotation` WHERE quotation_id  =".$qid;
  $result = mysqli_query($conn,$query);
  if ($result == 1){
      echo "1";
  }
  else
     echo "0";

?>