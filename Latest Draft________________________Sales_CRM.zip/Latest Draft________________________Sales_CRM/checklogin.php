<?php
 include ("connection.php");
 $conn = connect();
 $uname = $_POST['susername'];
 $pwd = $_POST['spwd'];

 $result = mysqli_query($conn, "SELECT count(*) as cnt FROM staff where username = '".$uname."' and password = '".$pwd."'");                                                                   
 $row = mysqli_fetch_assoc($result);
 echo $row["cnt"];
 if ($row["cnt"] == 1){
    session_start();
    $_SESSION['uname'] = $uname;
    header("Location:dashboard_staff.php");
 }
 else{
   header("Location:index.php");
 }
?>