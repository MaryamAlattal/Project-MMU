<?php
//select *from leads_tab where YEAR(updated_date) = 2023 AND MONTH(updated_date) = 3;
?>
<!DOCTYPE html>
<html lang="en">
<?php

include ("trigger_query.php");
?>
<body class="bg-gradient-primary">



        <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
               
                    <div class="col-lg-12">
                        <div class="p-10">
                            <div class="text-center">
                                <h1 class="h4 text-gray-900 mb-4">Upload a Quotation!</h1>
                            </div>
                      
                            <form class="user" enctype="multipart/form-data" action='addquotationtodb.php' method="post">
                                <input type="hidden" name="leadid" value="<?php echo $_REQUEST['lid']; ?>">
                                <div class="form-group row">
                                    <div class="col-sm-12 mb-3 mb-sm-0">
                               
                                    <select class="form-control form-control-select" name="offer">
                                            <option> Select Any Offer </option>
                                            <option> Offer 1 </option>
                                            <option> Offer 2 </option>
                                            <option> Offer 3 </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-sm-12 mb-3 mb-sm-0">
                                    <?php $plist = show_products(); ?>
                                    <select class="form-control form-control-select" name="productname">
                                        <option> Select Product </option>
                                        <?php
                                        while($row = mysqli_fetch_assoc($plist)) {
                                       ?> <option value="<?php echo $row['product_id']; ?>"> <?php echo $row['title']; ?> </option>
                                      <?php
                                        }
                                        ?>
                                    </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <input type="number" class="form-control form-control-user" name="quantity"
                                        placeholder="Quantity">
                                </div>
                                 

                                    <div class="col-sm-6 mb-3 mb-sm-0">
                                        <input type="number" class="form-control form-control-user" name="PriceofProduct"
                                            placeholder="Price">
                                    </div>
                                    </div>
                                    <div class="form-group row">
                                    <div class="col-sm-12 mb-3 mb-sm-0">
                                    <input type="file" placeholder="upload quotation" name="qfile">
                                           
                                    </div>
                                </div>
                                 
                                
                                <button name="uploadbtn" type='submit' class="btn btn-primary btn-user btn-block">
                                    Upload and Store Quotation
                                </button>
                                <hr>
                               
                                <!-- <a href="index.html" class="btn btn-facebook btn-user btn-block">
                                    <i class="fab fa-facebook-f fa-fw"></i> Register with Facebook
                                </a> -->
                            </form>
       
                           
                        </div>
                    </div>
                </div>
            </div>
       

    </div>
   </body>
</html>
<?php
if (isset($_POST["register"])) {
    require_once ("trigger_query.php");
   $flag = addleadtodb();
   if ($flag){
    ?>
    <script> alert("record inserted "); </script>

    <?php
   }
   else{?>
    <script> alert("Error in Insertion"); </script>
    <?php
   }
    return;
}
?>