<?php
include "connection.php";
//************* uploading file to quotation folder */
$target_dir = "quotations/";
$target_file = $target_dir . basename($_FILES["qfile"]["name"]);
$uploadOk = 1;
$FileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image

  $check = getimagesize($_FILES["qfile"]["tmp_name"]);
  if($FileType == "doc" || $FileType == "pdf" || $FileType == "xls" || $FileType == "csv" || $FileType == "docx") {
     $uploadOk = 1;
}
else{
    $uploadOk = 0;
}

if ($uploadOk == 1){
    if (move_uploaded_file($_FILES["qfile"]["tmp_name"], $target_file)) {
            $conn = Connect();
            $lead_id = $_REQUEST['leadid'];
            $offer = $_POST['offer'];
            $productID = $_POST['productname'];
            $quantity = $_POST['quantity'];
            $target_file = $_FILES["qfile"]["name"];
            $price  = $_POST['PriceofProduct'];


            $sql = "INSERT INTO quotation (lead_id,offer,product_id,
                                quantity,file,price)
                
                        values(".$lead_id.",'".$offer."','".$productID."',
                                '".$quantity."','".$target_file."',".$price.")";

            if(mysqli_query($conn,$sql)){
                //echo 'inserted record successfully!';
                header("Location:converttooppo.php");
    }else{
            //echo 'failed, try again';
            header("Location:converttooppo.php");
    }
        echo "The file ". htmlspecialchars( basename( $_FILES["qfile"]["name"])). " has been uploaded.";
      } else {
        echo "Sorry, there was an error uploading your file.";
      }
}

/////////////////************ end of code to upload */
// $conn =Connect();
// $lead_id = $_REQUEST['leadid'];
// $offer = $_POST['offer'];
// $productID = $_POST['productname'];
// $quantity = $_POST['quantity'];
// $target_file = $_FILES["qfile"]["name"];
// $price  = $_POST['PriceofProduct'];


// $sql = "INSERT INTO quotation (lead_id,offer,product_id,
//                     quantity,file,price)
    
//               values(".$lead_id.",'".$offer."','".$productID."',
//                      '".$quantity."','".$target_file."',".$price.")";

// if(mysqli_query($conn,$sql)){
//     //echo 'inserted record successfully!';
//     header("Location:converttooppo.php");
// }else{
//     //echo 'failed, try again';
//     header("Location:addlead.php");
// }

?>