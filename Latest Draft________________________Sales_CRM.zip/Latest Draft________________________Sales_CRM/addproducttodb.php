<?php
include "connection.php";
$conn =Connect();
$title = $_POST['title'];
$category = $_POST['category'];
$manufacturer = $_POST['manufacturer'];
$price = $_POST['price'];
$sku = $_POST['sku'];
$sizes  = $_POST['sizes'];
$description  = $_POST['description'];


$sql = "INSERT INTO product (title,category_id,manufacturer,price,
              SKU,sizes,description) 
              values('".$title."','".$category."','".$manufacturer."',".$price.",
                     ".$sku.",'".$sizes."','".$description."')";

if(mysqli_query($conn,$sql)){
    //echo 'inserted record successfully!';
    header("Location:dashboard_staff.php");
}else{
    //echo 'failed, try again';
    header("Location:addproduct.php");
}
?>