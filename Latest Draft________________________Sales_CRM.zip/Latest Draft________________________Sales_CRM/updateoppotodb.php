<?php
include ("connection.php");
require_once("trigger_query.php");
$conn = connect();
$oid = $_REQUEST['oid'];
$title = $_REQUEST['title'];
$qid = getquotationidfromtitle($title);
$name = $_REQUEST['name'];
echo "============".$name;
$sid = getemployeeidbyname($name);
$query = "update opportunity set employee_id =".$sid.",quotation_id = ".$qid." where opportunity_id = ".$oid;
echo "<br>".$query;
$count = mysqli_query($conn,$query);
echo $count;
?>