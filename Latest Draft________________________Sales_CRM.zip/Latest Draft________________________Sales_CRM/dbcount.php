<?php
//     $servername = "localhost";
//     $database = "crmdb";
//     $username = "root";
//     $password = "";
//                                                    // Create connection
// echo "establishing connection";
// $conn = mysqli_connect($servername, $username, $password, $database);
// if($conn){
//     echo "connection successful";
// }
include("connection.php");
$conn = connect();
if ($result = mysqli_query($conn, "SELECT count(*) as cnt FROM leads_tab")) {
    echo "Returned rows are: " . mysqli_num_rows($result);

    // Free result set
   // mysqli_free_result($result);
  }
  $row = mysqli_fetch_assoc($result);
  echo "---------->".$row["cnt"];
  mysqli_close($conn);
                                            ?>